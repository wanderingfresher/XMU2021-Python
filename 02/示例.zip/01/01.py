import re
import csv
import copy
import urllib
import requests
from lxml import etree
from urllib import parse
from urllib import request
from bs4 import BeautifulSoup

import time
import random

# time.sleep(random.random()*2)
n = 2

# 储存结构体
class Person:
    id = ''
    name = ''
    count = 0

    def __init__(self, s1='', s2='', n=0):
        self.id = s1
        self.name = s2
        self.count = n


# 全局变量设置
# 用列表行使队列操作
workQ = []  # 进行广度遍历的工作队列 储存id与姓名
saveQ = []  # 存储已经完成爬取的人物id与姓名与同名人物次序


# 网页
def getHtml(url):
    # 延时
    time.sleep(random.random() * n)
    # 爬取网页
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) '
                      'AppleWebKit/537.36 (KHTML, like Gecko) '
                      'Chrome/67.0.3396.99 Safari/537.36'
    }
    # 利用请求地址和请求头部构造请求对象
    req = urllib.request.Request(url=url, headers=headers, method='GET')

    # 发送请求，获得响应
    # 获取目标网址所有信息
    response = urllib.request.urlopen(req)

    # 读取响应，获得文本
    # 定义所有信息的文本
    html = response.read().decode('utf-8')
    return html

# 关系  通过request抓包
def getRelation(id, name, url):
    # 延时
    time.sleep(random.random() * n)
    # 爬取关系 b  抓包

    headers = {
        'User-Agent ': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) '
                       'Chrome/111.0.0.0 Safari/537.36 Edg',
        "Referer": url
    }
    # 将API链接的查询实符串传给Params参数
    params = {
        'lemmaId': id,
        'lemmaTitle': name
    }

    # 暂时避免不了request爬取抓包
    res = requests.get('https://baike.baidu.com/starmap/api/gethumanrelationcard', headers=headers, params=params)
    # 返回结果力JSQN格式,调用json.()方法解析
    items = res.json()
    b = []
    # 拼接成如'好友:李白-1043\n好友:苏涣-10652\n' 标准形式
    for x in items['list']:
        s=x['relationName']+':'+x['lemmaTitle']+'-'+str(x['lemmaId'])+'\n'
        b.append(s)
    b = "".join(b)

    return b

# 基本信息
def getBasic(html):
    # 解析基本信息 a
    soup = BeautifulSoup(html, features="html.parser")
    company_items = soup.find_all("div", class_="basic-info J-basic-info cmn-clearfix")

    a = []
    for i in company_items:
        x = i.text.strip()
        a.append(x)

    a = "".join(a)
    a = "".join(a.split('\xa0'))
    a = "\n".join(a.split('\n\n'))
    a = re.sub(u"\\[.*?]", "", a)
    a = "\n".join(a.split('\n\n'))
    a = "\n".join(a.split('\n\n'))

    return a

# 介绍
def getIntro(html):
    # 解析介绍 c
    # 构造 _Element 对象
    html1 = etree.HTML(html)
    # 使用 xpath 匹配数据，得到匹配字符串列表
    sen_list = html1.xpath(
        '//div[contains(@class,"lemma-summary") or contains(@class,"lemmaWgt-lemmaSummary")]//text()')
    # 过滤数据，去掉空白
    sen_list_after_filter = [item.strip('\n') for item in sen_list]
    # 将字符串列表连成字符串并返回
    c = ''.join(sen_list_after_filter)
    c = re.sub(u"\\[.*?]", "", c)

    return c

# 经历
def getExperence(intro, html):
    # 解析生平 d

    # 构造 _Element 对象
    html1 = etree.HTML(html)
    sen_list = html1.xpath('//div[contains(@class,"para")]//text()')
    # 过滤数据，去掉空白
    sen_list_after_filter = [item.strip('\n') for item in sen_list]
    # 将字符串列表连成字符串并返回
    d = ''.join(sen_list_after_filter)
    d = re.sub(u"\\[.*?]", "", d)
    # 由于履历中有介绍重复一部分,将这一部分正则除去
    d = d.replace(intro, '', 1)

    return d

# 获得初始人物id,注意 整个程序中仅执行一次,仅根据初始人物数量决定
def spiderGetFirstId(content):
    url = 'https://baike.baidu.com/item/' + parse.quote(content)

    # 获取目标网址所有信息
    demo = getHtml(url)  # 定义所有信息的文本
    soup = BeautifulSoup(demo, 'html.parser')  # BeautifulSoup中的方法

    a = soup.find('link', rel="alternate", hreflang="x-default")
    a = a.get('href')
    a = a.split('/')[-1]  # 获得lemmaid
    # time.sleep(random.random() * n)
    return a

# 根据id,姓名构造网址
def urlConvert(id, name):
    url = 'https://baike.baidu.com/item/' + parse.quote(name) + '/' + id
    return url

# 对输入姓名进行归一化处理,以满足自定义数据结构
def intializeInputName(content):
    id = spiderGetFirstId(content)
    name = content
    return Person(id, name, 0)

# 执行四项信息爬取
def queryBaidubaike(id, name):
    url = urlConvert(id, name)
    html = getHtml(url)
    relation = getRelation(id, name, url)
    # basic = getBasic(html)
    # intro = getIntro(html)
    # experience = getExperence(intro, html)


    # print(relation)
    # print(basic)
    # print(intro)
    # print(experience)
    return relation

# 写入
def csvWriteInfo(id,name,count,relation):
    # csv header
    fieldnames = ['id', 'name', '同名次序', '关系']

    row = [{
            'id': id,
            'name': name,
            '同名次序': count,
            '关系': relation
        }]
    # 按照列标题写入
    with open('result_data.csv', 'a+', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writerows(row)

# 中心人物的关系提取处理后装入工作队
def updateWorkQ(relation):
    # 以下处理将关系字符串分为关系名,名字,id三个一组的列表
    b = re.split('-|:|\n', relation)
    i = 0
    name = []
    id = []
    # 首位为1计数下标,模3为2即为名字,整除即为id, 分别加入相应列表
    for t in b:
        i = i + 1
        if i % 3 == 2:
            name.append(t)
        elif i % 3 == 0:
            id.append(t)
            n = i // 3 - 1
            # 每处理3个,取两个列表的同下标元素为一组,初始化个人信息,入工作队
            a = Person(id[n], name[n])
            workQ.append(a)


# 执行爬取,返回多条信息,写入,更新工作队
def spiderSearchWrite(ele):
    # 获得信息
    relation = queryBaidubaike(ele.id,ele.name)

    # 写入文件
    csvWriteInfo(ele.id, ele.name, ele.count, relation)
    # 更新工作队
    updateWorkQ(relation)




# csv header
fieldnames = ['id', 'name', '同名次序','关系']
# 写入列标题
with open('result_data.csv', 'w+', encoding='utf-8-sig', newline='') as f:
    writer = csv.DictWriter(f, fieldnames=fieldnames)
    writer.writeheader()


content = '成龙'    #input()

ele = intializeInputName(content)
workQ.append(ele)

flag1=0
total = 0
while 1:
    # 跳出条件
    if total == 200 or workQ == []:
        flag1=1
        break

    # 从工作队取出一个元素,查重,计数并储存
    ele = copy.deepcopy(workQ.pop(0))

    # 以下为对出队元素进行检查,满足要求则进行检索爬取
    # 确定该名为第几个该名人物(为1则无重名,其为第一个)
    count = 1
    flag2 = 0
    for a in saveQ:
        if a.name == ele.name:
            if a.id!=ele.id:
                count = count + 1
            else: # 当前人信息已经在储存队中,则跳过本轮循环
                flag2=1
    if flag2==1:
        continue
    # 若该条信息首次出现,更新重复数,存入储存队,总数加1
    ele.count = count
    saveQ.append(ele)
    total = total + 1


    # 执行爬取,写入,
    print(total,':',ele.id, ele.name)
    spiderSearchWrite(ele)

print("total:",total)

